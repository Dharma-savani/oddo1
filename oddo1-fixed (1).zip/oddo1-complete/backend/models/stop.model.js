const { v4: uuid } = require("uuid");
const { getCollection, saveCollection } = require("../config/db");

const STOPS = "stops";
const STOP_ACTIVITIES = "stopActivities";

/* ---------------------------- Stops ---------------------------- */

function findByTrip(tripId) {
  return getCollection(STOPS)
    .filter((s) => s.tripId === tripId)
    .sort((a, b) => a.order - b.order);
}

function findById(id) {
  return getCollection(STOPS).find((s) => s.id === id) || null;
}

function create({ tripId, cityId, startDate, endDate }) {
  const stops = getCollection(STOPS);
  const order = stops.filter((s) => s.tripId === tripId).length;
  const stop = {
    id: uuid(),
    tripId,
    cityId,
    startDate: startDate || null,
    endDate: endDate || null,
    order,
    estimatedStayCost: 0,
    estimatedTransportCost: 0,
  };
  stops.push(stop);
  saveCollection(STOPS, stops);
  return stop;
}

function update(id, patch) {
  const stops = getCollection(STOPS);
  const idx = stops.findIndex((s) => s.id === id);
  if (idx === -1) return null;
  stops[idx] = { ...stops[idx], ...patch, id: stops[idx].id };
  saveCollection(STOPS, stops);
  return stops[idx];
}

function remove(id) {
  saveCollection(STOPS, getCollection(STOPS).filter((s) => s.id !== id));
  // Cascade: remove activities attached to this stop
  saveCollection(
    STOP_ACTIVITIES,
    getCollection(STOP_ACTIVITIES).filter((sa) => sa.stopId !== id)
  );
}

function reorder(tripId, orderedStopIds) {
  const stops = getCollection(STOPS);
  orderedStopIds.forEach((stopId, index) => {
    const idx = stops.findIndex((s) => s.id === stopId && s.tripId === tripId);
    if (idx !== -1) stops[idx].order = index;
  });
  saveCollection(STOPS, stops);
  return findByTrip(tripId);
}

/* ------------------------ Stop Activities ------------------------ */

function findActivitiesByStop(stopId) {
  return getCollection(STOP_ACTIVITIES).filter((sa) => sa.stopId === stopId);
}

function findActivitiesByStops(stopIds) {
  return getCollection(STOP_ACTIVITIES).filter((sa) => stopIds.includes(sa.stopId));
}

function addActivity({ stopId, activityId, scheduledDate, scheduledTime }) {
  const list = getCollection(STOP_ACTIVITIES);
  const entry = {
    id: uuid(),
    stopId,
    activityId,
    scheduledDate: scheduledDate || null,
    scheduledTime: scheduledTime || null,
  };
  list.push(entry);
  saveCollection(STOP_ACTIVITIES, list);
  return entry;
}

function removeActivity(id) {
  saveCollection(
    STOP_ACTIVITIES,
    getCollection(STOP_ACTIVITIES).filter((sa) => sa.id !== id)
  );
}

module.exports = {
  findByTrip,
  findById,
  create,
  update,
  remove,
  reorder,
  findActivitiesByStop,
  findActivitiesByStops,
  addActivity,
  removeActivity,
};
