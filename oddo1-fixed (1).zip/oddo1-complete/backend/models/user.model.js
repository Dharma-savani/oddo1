const { v4: uuid } = require("uuid");
const { getCollection, saveCollection } = require("../config/db");

const COLLECTION = "users";

function findAll() {
  return getCollection(COLLECTION);
}

function findById(id) {
  return findAll().find((u) => u.id === id) || null;
}

function findByEmail(email) {
  const normalized = String(email || "").trim().toLowerCase();
  return findAll().find((u) => u.email === normalized) || null;
}

function create({ fullname, email, passwordHash }) {
  const users = findAll();
  const user = {
    id: uuid(),
    fullname,
    email: String(email).trim().toLowerCase(),
    passwordHash,
    avatar: null,
    language: "English",
    isAdmin: users.length === 0, // first registered user becomes admin
    createdAt: new Date().toISOString(),
  };
  users.push(user);
  saveCollection(COLLECTION, users);
  return user;
}

function update(id, patch) {
  const users = findAll();
  const idx = users.findIndex((u) => u.id === id);
  if (idx === -1) return null;
  users[idx] = { ...users[idx], ...patch, id: users[idx].id };
  saveCollection(COLLECTION, users);
  return users[idx];
}

function remove(id) {
  const users = findAll().filter((u) => u.id !== id);
  saveCollection(COLLECTION, users);
}

function toPublic(user) {
  if (!user) return null;
  const { passwordHash, ...rest } = user;
  return rest;
}

module.exports = { findAll, findById, findByEmail, create, update, remove, toPublic };
