const { v4: uuid } = require("uuid");
const { getCollection, saveCollection } = require("../config/db");

const COLLECTION = "cities";

function findAll({ search, country } = {}) {
  let cities = getCollection(COLLECTION);
  if (search) {
    const q = search.toLowerCase();
    cities = cities.filter(
      (c) =>
        c.name.toLowerCase().includes(q) || c.country.toLowerCase().includes(q)
    );
  }
  if (country) {
    cities = cities.filter((c) => c.country.toLowerCase() === country.toLowerCase());
  }
  return cities.sort((a, b) => b.popularity - a.popularity);
}

function findById(id) {
  return getCollection(COLLECTION).find((c) => c.id === id) || null;
}

function create(data) {
  const cities = getCollection(COLLECTION);
  const city = { id: uuid(), ...data };
  cities.push(city);
  saveCollection(COLLECTION, cities);
  return city;
}

function bulkCreate(list) {
  const cities = getCollection(COLLECTION);
  const created = list.map((c) => ({ id: uuid(), ...c }));
  saveCollection(COLLECTION, [...cities, ...created]);
  return created;
}

module.exports = { findAll, findById, create, bulkCreate };
