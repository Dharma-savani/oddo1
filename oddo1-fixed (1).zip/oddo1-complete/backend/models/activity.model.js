const { v4: uuid } = require("uuid");
const { getCollection, saveCollection } = require("../config/db");

const COLLECTION = "activities";

function findAll({ cityId, type, search, maxCost } = {}) {
  let activities = getCollection(COLLECTION);
  if (cityId) activities = activities.filter((a) => a.cityId === cityId);
  if (type) activities = activities.filter((a) => a.type === type);
  if (maxCost) activities = activities.filter((a) => a.cost <= Number(maxCost));
  if (search) {
    const q = search.toLowerCase();
    activities = activities.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        (a.description || "").toLowerCase().includes(q)
    );
  }
  return activities;
}

function findById(id) {
  return getCollection(COLLECTION).find((a) => a.id === id) || null;
}

function create(data) {
  const activities = getCollection(COLLECTION);
  const activity = { id: uuid(), ...data };
  activities.push(activity);
  saveCollection(COLLECTION, activities);
  return activity;
}

function bulkCreate(list) {
  const activities = getCollection(COLLECTION);
  const created = list.map((a) => ({ id: uuid(), ...a }));
  saveCollection(COLLECTION, [...activities, ...created]);
  return created;
}

module.exports = { findAll, findById, create, bulkCreate };
