const stopModel = require("./stop.model");
const activityModel = require("./activity.model");
const tripModel = require("./trip.model");

/**
 * Computes a full budget breakdown for a trip:
 * - activities: sum of every activity attached to every stop
 * - transport/stay: manual per-stop estimates entered in the itinerary builder
 * - meals: flat manual addition (trip.budgetExtras.meals) since it's not
 *   tied to a specific activity
 * - perDayAverage + overBudgetDays: computed against trip.budgetLimit (optional)
 */
function computeForTrip(tripId) {
  const trip = tripModel.findById(tripId);
  if (!trip) return null;

  const stops = stopModel.findByTrip(tripId);
  const stopIds = stops.map((s) => s.id);
  const stopActivities = stopModel.findActivitiesByStops(stopIds);

  let activitiesCost = 0;
  const activityBreakdown = [];
  stopActivities.forEach((sa) => {
    const activity = activityModel.findById(sa.activityId);
    if (activity) {
      activitiesCost += Number(activity.cost) || 0;
      activityBreakdown.push({
        stopId: sa.stopId,
        activityId: activity.id,
        name: activity.name,
        cost: activity.cost,
        scheduledDate: sa.scheduledDate,
      });
    }
  });

  const transportCost = stops.reduce(
    (sum, s) => sum + (Number(s.estimatedTransportCost) || 0),
    0
  );
  const stayCost = stops.reduce(
    (sum, s) => sum + (Number(s.estimatedStayCost) || 0),
    0
  );
  const mealsCost = Number(trip.budgetExtras && trip.budgetExtras.meals) || 0;
  const extraTransport = Number(trip.budgetExtras && trip.budgetExtras.transport) || 0;
  const extraStay = Number(trip.budgetExtras && trip.budgetExtras.stay) || 0;

  const totalTransport = transportCost + extraTransport;
  const totalStay = stayCost + extraStay;
  const total = totalTransport + totalStay + activitiesCost + mealsCost;

  let days = 1;
  if (trip.startDate && trip.endDate) {
    const start = new Date(trip.startDate);
    const end = new Date(trip.endDate);
    const diff = Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1;
    days = diff > 0 ? diff : 1;
  }

  const perDayAverage = Math.round((total / days) * 100) / 100;

  return {
    tripId,
    breakdown: {
      transport: Math.round(totalTransport * 100) / 100,
      stay: Math.round(totalStay * 100) / 100,
      activities: Math.round(activitiesCost * 100) / 100,
      meals: Math.round(mealsCost * 100) / 100,
    },
    total: Math.round(total * 100) / 100,
    days,
    perDayAverage,
    activityBreakdown,
    budgetLimit: trip.budgetLimit || null,
    overBudget: trip.budgetLimit ? total > trip.budgetLimit : false,
  };
}

module.exports = { computeForTrip };
