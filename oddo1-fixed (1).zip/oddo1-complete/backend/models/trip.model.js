const { v4: uuid } = require("uuid");
const { getCollection, saveCollection } = require("../config/db");

const COLLECTION = "trips";

function findAll() {
  return getCollection(COLLECTION);
}

function findByUser(userId) {
  return findAll()
    .filter((t) => t.userId === userId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function findById(id) {
  return findAll().find((t) => t.id === id) || null;
}

function findByShareToken(token) {
  return findAll().find((t) => t.shareToken === token) || null;
}

function create({ userId, name, description, startDate, endDate, coverPhoto }) {
  const trips = findAll();
  const trip = {
    id: uuid(),
    userId,
    name,
    description: description || "",
    startDate: startDate || null,
    endDate: endDate || null,
    coverPhoto: coverPhoto || null,
    isPublic: false,
    shareToken: null,
    budgetExtras: { transport: 0, stay: 0, meals: 0 }, // manual budget additions
    createdAt: new Date().toISOString(),
  };
  trips.push(trip);
  saveCollection(COLLECTION, trips);
  return trip;
}

function update(id, patch) {
  const trips = findAll();
  const idx = trips.findIndex((t) => t.id === id);
  if (idx === -1) return null;
  trips[idx] = { ...trips[idx], ...patch, id: trips[idx].id };
  saveCollection(COLLECTION, trips);
  return trips[idx];
}

function remove(id) {
  saveCollection(COLLECTION, findAll().filter((t) => t.id !== id));
}

module.exports = { findAll, findByUser, findById, findByShareToken, create, update, remove };
