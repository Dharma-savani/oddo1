const activityModel = require("../models/activity.model");
const cityModel = require("../models/city.model");

function list(req, res) {
  const { cityId, type, search, maxCost } = req.query;
  const activities = activityModel.findAll({ cityId, type, search, maxCost });
  res.json({ activities });
}

function getOne(req, res) {
  const activity = activityModel.findById(req.params.id);
  if (!activity) return res.status(404).json({ message: "Activity not found." });
  res.json({ activity });
}

function create(req, res) {
  const { cityId, name, type, cost, duration, description, image } = req.body;
  if (!cityId || !name) {
    return res.status(400).json({ message: "cityId and name are required." });
  }
  if (!cityModel.findById(cityId)) {
    return res.status(400).json({ message: "cityId does not match an existing city." });
  }
  const activity = activityModel.create({
    cityId,
    name,
    type: type || "Sightseeing",
    cost: cost || 0,
    duration: duration || "2 hours",
    description: description || "",
    image: image || null,
  });
  res.status(201).json({ activity });
}

module.exports = { list, getOne, create };
