const tripModel = require("../models/trip.model");
const budgetModel = require("../models/budget.model");

function getBudget(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!trip) return res.status(404).json({ message: "Trip not found." });
  if (trip.userId !== req.userId) {
    return res.status(403).json({ message: "You do not have access to this trip." });
  }

  const budget = budgetModel.computeForTrip(trip.id);
  res.json({ budget });
}

module.exports = { getBudget };
