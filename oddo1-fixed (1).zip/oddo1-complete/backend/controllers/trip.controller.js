const { v4: uuid } = require("uuid");
const tripModel = require("../models/trip.model");
const stopModel = require("../models/stop.model");
const cityModel = require("../models/city.model");
const activityModel = require("../models/activity.model");

/* ------------------------------- helpers ------------------------------- */

function serializeTrip(trip) {
  const stops = stopModel.findByTrip(trip.id).map((stop) => {
    const city = cityModel.findById(stop.cityId);
    const activities = stopModel.findActivitiesByStop(stop.id).map((sa) => {
      const activity = activityModel.findById(sa.activityId);
      return { ...sa, activity };
    });
    return { ...stop, city, activities };
  });
  return { ...trip, stops };
}

function assertOwnership(req, res, trip) {
  if (!trip) {
    res.status(404).json({ message: "Trip not found." });
    return false;
  }
  if (trip.userId !== req.userId) {
    res.status(403).json({ message: "You do not have access to this trip." });
    return false;
  }
  return true;
}

/* --------------------------------- trips --------------------------------- */

function list(req, res) {
  const trips = tripModel.findByUser(req.userId).map(serializeTrip);
  res.json({ trips });
}

function getOne(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;
  res.json({ trip: serializeTrip(trip) });
}

function create(req, res) {
  const { name, description, startDate, endDate, coverPhoto } = req.body;
  if (!name) return res.status(400).json({ message: "Trip name is required." });

  const trip = tripModel.create({
    userId: req.userId,
    name,
    description,
    startDate,
    endDate,
    coverPhoto,
  });
  res.status(201).json({ trip: serializeTrip(trip) });
}

function update(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;

  const { name, description, startDate, endDate, coverPhoto, budgetLimit, budgetExtras } = req.body;
  const patch = {};
  if (name !== undefined) patch.name = name;
  if (description !== undefined) patch.description = description;
  if (startDate !== undefined) patch.startDate = startDate;
  if (endDate !== undefined) patch.endDate = endDate;
  if (coverPhoto !== undefined) patch.coverPhoto = coverPhoto;
  if (budgetLimit !== undefined) patch.budgetLimit = budgetLimit;
  if (budgetExtras !== undefined) patch.budgetExtras = { ...trip.budgetExtras, ...budgetExtras };

  const updated = tripModel.update(trip.id, patch);
  res.json({ trip: serializeTrip(updated) });
}

function remove(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;
  tripModel.remove(trip.id);
  res.json({ message: "Trip deleted." });
}

function share(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;
  const shareToken = trip.shareToken || uuid();
  const updated = tripModel.update(trip.id, { isPublic: true, shareToken });
  res.json({ trip: serializeTrip(updated), shareUrl: `/publicitinerary.html?token=${shareToken}` });
}

function unshare(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;
  const updated = tripModel.update(trip.id, { isPublic: false });
  res.json({ trip: serializeTrip(updated) });
}

function getPublic(req, res) {
  const trip = tripModel.findByShareToken(req.params.token);
  if (!trip || !trip.isPublic) {
    return res.status(404).json({ message: "This shared itinerary is not available." });
  }
  res.json({ trip: serializeTrip(trip) });
}

function copyPublic(req, res) {
  const source = tripModel.findByShareToken(req.params.token);
  if (!source || !source.isPublic) {
    return res.status(404).json({ message: "This shared itinerary is not available." });
  }
  const copy = tripModel.create({
    userId: req.userId,
    name: `${source.name} (copy)`,
    description: source.description,
    startDate: source.startDate,
    endDate: source.endDate,
    coverPhoto: source.coverPhoto,
  });
  stopModel.findByTrip(source.id).forEach((stop) => {
    const newStop = stopModel.create({
      tripId: copy.id,
      cityId: stop.cityId,
      startDate: stop.startDate,
      endDate: stop.endDate,
    });
    stopModel.update(newStop.id, {
      estimatedStayCost: stop.estimatedStayCost,
      estimatedTransportCost: stop.estimatedTransportCost,
    });
    stopModel.findActivitiesByStop(stop.id).forEach((sa) => {
      stopModel.addActivity({
        stopId: newStop.id,
        activityId: sa.activityId,
        scheduledDate: sa.scheduledDate,
        scheduledTime: sa.scheduledTime,
      });
    });
  });
  res.status(201).json({ trip: serializeTrip(tripModel.findById(copy.id)) });
}

/* --------------------------------- stops --------------------------------- */

function addStop(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;

  const { cityId, startDate, endDate } = req.body;
  if (!cityId) return res.status(400).json({ message: "cityId is required." });
  if (!cityModel.findById(cityId)) {
    return res.status(400).json({ message: "cityId does not match an existing city." });
  }

  const stop = stopModel.create({ tripId: trip.id, cityId, startDate, endDate });
  res.status(201).json({ trip: serializeTrip(tripModel.findById(trip.id)), stop });
}

function updateStop(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;

  const stop = stopModel.findById(req.params.stopId);
  if (!stop || stop.tripId !== trip.id) {
    return res.status(404).json({ message: "Stop not found on this trip." });
  }

  const { startDate, endDate, estimatedStayCost, estimatedTransportCost } = req.body;
  const patch = {};
  if (startDate !== undefined) patch.startDate = startDate;
  if (endDate !== undefined) patch.endDate = endDate;
  if (estimatedStayCost !== undefined) patch.estimatedStayCost = estimatedStayCost;
  if (estimatedTransportCost !== undefined) patch.estimatedTransportCost = estimatedTransportCost;

  stopModel.update(stop.id, patch);
  res.json({ trip: serializeTrip(tripModel.findById(trip.id)) });
}

function removeStop(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;

  const stop = stopModel.findById(req.params.stopId);
  if (!stop || stop.tripId !== trip.id) {
    return res.status(404).json({ message: "Stop not found on this trip." });
  }
  stopModel.remove(stop.id);
  res.json({ trip: serializeTrip(tripModel.findById(trip.id)) });
}

function reorderStops(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;

  const { stopIds } = req.body;
  if (!Array.isArray(stopIds)) {
    return res.status(400).json({ message: "stopIds must be an array." });
  }
  stopModel.reorder(trip.id, stopIds);
  res.json({ trip: serializeTrip(tripModel.findById(trip.id)) });
}

/* ---------------------------- stop activities ---------------------------- */

function addActivityToStop(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;

  const stop = stopModel.findById(req.params.stopId);
  if (!stop || stop.tripId !== trip.id) {
    return res.status(404).json({ message: "Stop not found on this trip." });
  }

  const { activityId, scheduledDate, scheduledTime } = req.body;
  if (!activityId) return res.status(400).json({ message: "activityId is required." });
  if (!activityModel.findById(activityId)) {
    return res.status(400).json({ message: "activityId does not match an existing activity." });
  }

  stopModel.addActivity({ stopId: stop.id, activityId, scheduledDate, scheduledTime });
  res.status(201).json({ trip: serializeTrip(tripModel.findById(trip.id)) });
}

function removeActivityFromStop(req, res) {
  const trip = tripModel.findById(req.params.id);
  if (!assertOwnership(req, res, trip)) return;

  stopModel.removeActivity(req.params.activityLinkId);
  res.json({ trip: serializeTrip(tripModel.findById(trip.id)) });
}

module.exports = {
  serializeTrip,
  list,
  getOne,
  create,
  update,
  remove,
  share,
  unshare,
  getPublic,
  copyPublic,
  addStop,
  updateStop,
  removeStop,
  reorderStops,
  addActivityToStop,
  removeActivityFromStop,
};
