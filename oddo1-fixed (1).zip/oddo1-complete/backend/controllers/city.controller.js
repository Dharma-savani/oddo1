const cityModel = require("../models/city.model");

function list(req, res) {
  const { search, country } = req.query;
  const cities = cityModel.findAll({ search, country });
  res.json({ cities });
}

function getOne(req, res) {
  const city = cityModel.findById(req.params.id);
  if (!city) return res.status(404).json({ message: "City not found." });
  res.json({ city });
}

function create(req, res) {
  const { name, country, costIndex, popularity, image, description } = req.body;
  if (!name || !country) {
    return res.status(400).json({ message: "name and country are required." });
  }
  const city = cityModel.create({
    name,
    country,
    costIndex: costIndex || 50,
    popularity: popularity || 0,
    image: image || null,
    description: description || "",
  });
  res.status(201).json({ city });
}

module.exports = { list, getOne, create };
