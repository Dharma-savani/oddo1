const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const userModel = require("../models/user.model");

function signToken(userId) {
  return jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });
}

async function signup(req, res) {
  try {
    const { fullname, email, password } = req.body;
    if (!fullname || !email || !password) {
      return res.status(400).json({ message: "Full name, email and password are required." });
    }
    if (password.length < 6) {
      return res.status(400).json({ message: "Password must be at least 6 characters." });
    }
    if (userModel.findByEmail(email)) {
      return res.status(409).json({ message: "An account with this email already exists." });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const user = userModel.create({ fullname, email, passwordHash });
    const token = signToken(user.id);

    res.status(201).json({ token, user: userModel.toPublic(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to sign up." });
  }
}

async function login(req, res) {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required." });
    }

    const user = userModel.findByEmail(email);
    if (!user) {
      return res.status(401).json({ message: "Invalid email or password." });
    }

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) {
      return res.status(401).json({ message: "Invalid email or password." });
    }

    const token = signToken(user.id);
    res.json({ token, user: userModel.toPublic(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to log in." });
  }
}

function me(req, res) {
  const user = userModel.findById(req.userId);
  if (!user) return res.status(404).json({ message: "User not found." });
  res.json({ user: userModel.toPublic(user) });
}

function updateMe(req, res) {
  const { fullname, avatar, language } = req.body;
  const patch = {};
  if (fullname !== undefined) patch.fullname = fullname;
  if (avatar !== undefined) patch.avatar = avatar;
  if (language !== undefined) patch.language = language;

  const user = userModel.update(req.userId, patch);
  if (!user) return res.status(404).json({ message: "User not found." });
  res.json({ user: userModel.toPublic(user) });
}

function deleteMe(req, res) {
  userModel.remove(req.userId);
  res.json({ message: "Account deleted." });
}

module.exports = { signup, login, me, updateMe, deleteMe };
