const router = require("express").Router();
const tripController = require("../controllers/trip.controller");
const budgetController = require("../controllers/budget.controller");
const { requireAuth } = require("../middleware/auth.middleware");

// All trip routes require a logged-in user.
router.use(requireAuth);

router.get("/", tripController.list);
router.post("/", tripController.create);
router.get("/:id", tripController.getOne);
router.put("/:id", tripController.update);
router.delete("/:id", tripController.remove);

router.post("/:id/share", tripController.share);
router.post("/:id/unshare", tripController.unshare);
router.post("/:token/copy", tripController.copyPublic);

router.get("/:id/budget", budgetController.getBudget);

router.post("/:id/stops", tripController.addStop);
router.put("/:id/stops/:stopId", tripController.updateStop);
router.delete("/:id/stops/:stopId", tripController.removeStop);
router.put("/:id/stops-reorder", tripController.reorderStops);

router.post("/:id/stops/:stopId/activities", tripController.addActivityToStop);
router.delete("/:id/activities/:activityLinkId", tripController.removeActivityFromStop);

module.exports = router;
