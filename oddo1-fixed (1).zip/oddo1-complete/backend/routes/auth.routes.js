const router = require("express").Router();
const authController = require("../controllers/auth.controller");
const { requireAuth } = require("../middleware/auth.middleware");

router.post("/signup", authController.signup);
router.post("/login", authController.login);
router.get("/me", requireAuth, authController.me);
router.put("/me", requireAuth, authController.updateMe);
router.delete("/me", requireAuth, authController.deleteMe);

module.exports = router;
