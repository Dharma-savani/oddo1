const router = require("express").Router();
const cityController = require("../controllers/city.controller");

router.get("/", cityController.list);
router.get("/:id", cityController.getOne);
router.post("/", cityController.create);

module.exports = router;
