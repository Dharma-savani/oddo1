const router = require("express").Router();
const activityController = require("../controllers/activity.controller");

router.get("/", activityController.list);
router.get("/:id", activityController.getOne);
router.post("/", activityController.create);

module.exports = router;
