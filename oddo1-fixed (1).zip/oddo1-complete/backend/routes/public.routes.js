const router = require("express").Router();
const tripController = require("../controllers/trip.controller");

// Publicly viewable shared itinerary - no auth required.
router.get("/trips/:token", tripController.getPublic);

module.exports = router;
