require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");

const authRoutes = require("./routes/auth.routes");
const tripRoutes = require("./routes/trip.routes");
const cityRoutes = require("./routes/city.routes");
const activityRoutes = require("./routes/activity.routes");
const publicRoutes = require("./routes/public.routes");
const { seedIfEmpty } = require("./data/seed");

// Auto-seed real cities + activities on every boot if the database is
// empty, so City Search / Activity Search / Dashboard always have real
// data to show without anyone needing to run a manual seed step.
const seedResult = seedIfEmpty();
if (seedResult.seeded) {
  console.log(`Auto-seeded ${seedResult.cities} cities and ${seedResult.activities} activities.`);
}

const app = express();

app.use(cors()); // dev-friendly: allow the static frontend to call the API from any origin
app.use(express.json({ limit: "5mb" }));

app.get("/api/health", (req, res) => res.json({ status: "ok", service: "oddo1-backend" }));

app.use("/api/auth", authRoutes);
app.use("/api/trips", tripRoutes);
app.use("/api/cities", cityRoutes);
app.use("/api/activities", activityRoutes);
app.use("/api/public", publicRoutes);

// Serve the frontend static files directly from the backend too, so the whole
// app can run from a single `node server.js` if you don't want a separate
// static file server for the frontend folder.
const FRONTEND_DIR = path.join(__dirname, "..", "frontend");
app.use(express.static(FRONTEND_DIR));

// 404 handler for unknown API routes
app.use("/api", (req, res) => {
  res.status(404).json({ message: "Not found." });
});

// Generic error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "Something went wrong on the server." });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`oddo1 backend running on http://localhost:${PORT}`);
  console.log(`Frontend also served statically from ${FRONTEND_DIR}`);
});
