/**
 * data/seed.js
 * -----------------------------------------------------------------------
 * Seeds data/db.json with real-world cities + activities so City Search,
 * Activity Search, Dashboard, and Itinerary Builder all have data to show
 * the first time the app runs - no manual data entry required.
 *
 * `seedIfEmpty()` is called automatically every time the server boots
 * (see server.js), so this happens dynamically with zero setup steps.
 * It only ever adds data when the cities/activities collections are
 * empty, so it never touches or duplicates data once seeded.
 *
 * You can still run it by hand if you ever want to force a re-seed after
 * wiping data/db.json: `npm run seed`
 * -----------------------------------------------------------------------
 */
const { getCollection, saveCollection } = require("../config/db");
const { v4: uuid } = require("uuid");

// 40 real, well-known travel destinations spanning every continent, with
// realistic relative cost-of-living index (0-100) and popularity (0-100).
const cities = [
  { name: "Paris", country: "France", costIndex: 78, popularity: 98, image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800", description: "The City of Light - iconic art, food, and architecture." },
  { name: "Tokyo", country: "Japan", costIndex: 72, popularity: 97, image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800", description: "A dazzling blend of ultra-modern and traditional culture." },
  { name: "Bali", country: "Indonesia", costIndex: 35, popularity: 90, image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800", description: "Tropical beaches, temples, and lush rice terraces." },
  { name: "Rome", country: "Italy", costIndex: 65, popularity: 93, image: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=800", description: "Ancient ruins, world-class art, and unforgettable food." },
  { name: "Barcelona", country: "Spain", costIndex: 60, popularity: 88, image: "https://images.unsplash.com/photo-1583422409516-2895a77efded?w=800", description: "Gaudi architecture, beaches, and vibrant nightlife." },
  { name: "New York City", country: "USA", costIndex: 88, popularity: 95, image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800", description: "The city that never sleeps - culture, food, and skyline views." },
  { name: "Bangkok", country: "Thailand", costIndex: 30, popularity: 87, image: "https://images.unsplash.com/photo-1508009603885-50cf7c079365?w=800", description: "Street food, ornate temples, and a buzzing city energy." },
  { name: "Santorini", country: "Greece", costIndex: 70, popularity: 89, image: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800", description: "Whitewashed cliffside villages and iconic sunsets." },
  { name: "Cape Town", country: "South Africa", costIndex: 45, popularity: 80, image: "https://images.unsplash.com/photo-1580060839134-75a5edca2e99?w=800", description: "Table Mountain, coastline, and rich cultural history." },
  { name: "Sydney", country: "Australia", costIndex: 80, popularity: 86, image: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=800", description: "Harbour views, beaches, and laid-back city life." },
  { name: "Dubai", country: "UAE", costIndex: 82, popularity: 88, image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800", description: "Futuristic skyline, desert adventures, luxury shopping." },
  { name: "Amsterdam", country: "Netherlands", costIndex: 68, popularity: 85, image: "https://images.unsplash.com/photo-1534351590666-13e3e96b5017?w=800", description: "Canals, cycling culture, and world-class museums." },
  { name: "London", country: "United Kingdom", costIndex: 85, popularity: 94, image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800", description: "Royal history, world museums, and a legendary theatre scene." },
  { name: "Istanbul", country: "Turkey", costIndex: 42, popularity: 84, image: "https://images.unsplash.com/photo-1524231757912-21f4fe3a7200?w=800", description: "Where Europe meets Asia - bazaars, mosques, and Bosphorus views." },
  { name: "Kyoto", country: "Japan", costIndex: 60, popularity: 83, image: "https://images.unsplash.com/photo-1478436127897-769e1b3f0f36?w=800", description: "Thousands of temples, bamboo groves, and geisha districts." },
  { name: "Prague", country: "Czech Republic", costIndex: 48, popularity: 82, image: "https://images.unsplash.com/photo-1541849546-216549ae216d?w=800", description: "Fairy-tale old town, castles, and cobblestone charm." },
  { name: "Lisbon", country: "Portugal", costIndex: 52, popularity: 81, image: "https://images.unsplash.com/photo-1585208798174-6cedd86e019a?w=800", description: "Pastel hillside streets, trams, and Atlantic sunsets." },
  { name: "Vienna", country: "Austria", costIndex: 66, popularity: 79, image: "https://images.unsplash.com/photo-1516550893923-42d28e5677af?w=800", description: "Imperial palaces, classical music, and coffeehouse culture." },
  { name: "Marrakech", country: "Morocco", costIndex: 32, popularity: 78, image: "https://images.unsplash.com/photo-1489749798305-4fea3ae63d43?w=800", description: "Vibrant souks, riads, and the gateway to the Sahara." },
  { name: "Rio de Janeiro", country: "Brazil", costIndex: 50, popularity: 85, image: "https://images.unsplash.com/photo-1483729558449-99ef09a8c325?w=800", description: "Copacabana beaches, Christ the Redeemer, and carnival energy." },
  { name: "Buenos Aires", country: "Argentina", costIndex: 40, popularity: 76, image: "https://images.unsplash.com/photo-1589909202802-8f4aadce1849?w=800", description: "Tango, steakhouses, and European-style boulevards." },
  { name: "Cancun", country: "Mexico", costIndex: 55, popularity: 83, image: "https://images.unsplash.com/photo-1552074284-5e88ef1aef18?w=800", description: "Caribbean beaches, cenotes, and Mayan ruins nearby." },
  { name: "Seoul", country: "South Korea", costIndex: 62, popularity: 84, image: "https://images.unsplash.com/photo-1517154421773-0529f29ea451?w=800", description: "K-pop culture, palaces, and round-the-clock street food." },
  { name: "Singapore", country: "Singapore", costIndex: 84, popularity: 87, image: "https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=800", description: "Futuristic gardens, hawker food, and a spotless skyline." },
  { name: "Hong Kong", country: "China", costIndex: 80, popularity: 82, image: "https://images.unsplash.com/photo-1536599424071-0b215a388ba7?w=800", description: "Neon skyline, dim sum, and dramatic harbour views." },
  { name: "Reykjavik", country: "Iceland", costIndex: 75, popularity: 77, image: "https://images.unsplash.com/photo-1504829857797-ddff29c27927?w=800", description: "Northern lights, glaciers, and geothermal hot springs." },
  { name: "Queenstown", country: "New Zealand", costIndex: 70, popularity: 74, image: "https://images.unsplash.com/photo-1589871173980-5c353a8f6c9c?w=800", description: "Adventure capital - bungee jumping, fjords, and alpine lakes." },
  { name: "Cairo", country: "Egypt", costIndex: 28, popularity: 79, image: "https://images.unsplash.com/photo-1568322445389-f64ac9c7d5c1?w=800", description: "The Pyramids of Giza, the Nile, and ancient Egyptian history." },
  { name: "Jaipur", country: "India", costIndex: 22, popularity: 78, image: "https://images.unsplash.com/photo-1477587458883-47145ed94245?w=800", description: "The Pink City - forts, palaces, and vibrant bazaars." },
  { name: "Goa", country: "India", costIndex: 25, popularity: 80, image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=800", description: "Sun-soaked beaches, Portuguese heritage, and laid-back vibes." },
  { name: "Hanoi", country: "Vietnam", costIndex: 26, popularity: 76, image: "https://images.unsplash.com/photo-1509030450996-dd1a26dda07a?w=800", description: "Old Quarter street food, lakes, and nearby Halong Bay." },
  { name: "Kuala Lumpur", country: "Malaysia", costIndex: 38, popularity: 74, image: "https://images.unsplash.com/photo-1596422846543-75c6fc197f07?w=800", description: "Twin Towers skyline, street markets, and rainforest day trips." },
  { name: "Zurich", country: "Switzerland", costIndex: 95, popularity: 73, image: "https://images.unsplash.com/photo-1515488764276-beab7607c1e6?w=800", description: "Alpine lakes, precision, and effortless mountain access." },
  { name: "Berlin", country: "Germany", costIndex: 63, popularity: 83, image: "https://images.unsplash.com/photo-1560930950-5cc20e80e392?w=800", description: "Cutting-edge art, history, and legendary nightlife." },
  { name: "Copenhagen", country: "Denmark", costIndex: 82, popularity: 78, image: "https://images.unsplash.com/photo-1513622470522-26c3c8a854bc?w=800", description: "Colorful harbours, hygge cafes, and world-class design." },
  { name: "Edinburgh", country: "United Kingdom", costIndex: 66, popularity: 76, image: "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=800", description: "A medieval castle skyline and Scotland's storytelling capital." },
  { name: "Dublin", country: "Ireland", costIndex: 70, popularity: 75, image: "https://images.unsplash.com/photo-1590089415225-401ed6f9db8e?w=800", description: "Literary pubs, Georgian streets, and warm Irish hospitality." },
  { name: "Toronto", country: "Canada", costIndex: 72, popularity: 77, image: "https://images.unsplash.com/photo-1517090504586-fde19ea6066f?w=800", description: "Multicultural neighborhoods and the CN Tower skyline." },
  { name: "Vancouver", country: "Canada", costIndex: 74, popularity: 76, image: "https://images.unsplash.com/photo-1560814304-4f05b62af116?w=800", description: "Mountains meet ocean in Canada's most scenic city." },
  { name: "Melbourne", country: "Australia", costIndex: 76, popularity: 79, image: "https://images.unsplash.com/photo-1514395462725-fb4566210144?w=800", description: "Laneway cafes, street art, and a top-tier food scene." },
  { name: "Mumbai", country: "India", costIndex: 30, popularity: 85, image: "https://images.unsplash.com/photo-1529253355930-ddbe423a2ac7?w=800", description: "The city that never sleeps - Bollywood, Marine Drive, and street food." },
  { name: "Delhi", country: "India", costIndex: 28, popularity: 84, image: "https://images.unsplash.com/photo-1587474260584-136574528ed5?w=800", description: "Mughal monuments, bustling bazaars, and India's capital energy." },
  { name: "Surat", country: "India", costIndex: 24, popularity: 65, image: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=800", description: "The Diamond City - textile markets, riverfront, and Gujarati food." },
  { name: "Ahmedabad", country: "India", costIndex: 23, popularity: 68, image: "https://images.unsplash.com/photo-1600100397608-f320d5b41f70?w=800", description: "Heritage old city, Sabarmati Ashram, and famous street food." },
  { name: "Bengaluru", country: "India", costIndex: 32, popularity: 75, image: "https://images.unsplash.com/photo-1580500550469-45a37f6ff3bb?w=800", description: "India's tech capital, with gardens, breweries, and a buzzing food scene." },
  { name: "Chennai", country: "India", costIndex: 27, popularity: 66, image: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=800", description: "Marina Beach, temple architecture, and classic South Indian cuisine." },
  { name: "Kolkata", country: "India", costIndex: 24, popularity: 67, image: "https://images.unsplash.com/photo-1558431382-27e303142255?w=800", description: "Colonial architecture, literary cafes, and the City of Joy's culture." },
  { name: "Udaipur", country: "India", costIndex: 26, popularity: 74, image: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800", description: "The City of Lakes - romantic palaces and lakeside views." },
];

const activityTemplates = [
  { name: "City Walking Tour", type: "Sightseeing", cost: 15, duration: "2 hours", description: "Guided walk through the historic city center." },
  { name: "Local Food Tasting Tour", type: "Food", cost: 45, duration: "3 hours", description: "Sample the best street food and local specialties." },
  { name: "Museum Entry & Guided Tour", type: "Culture", cost: 25, duration: "2.5 hours", description: "Explore the city's most famous museum with a local guide." },
  { name: "Sunset Boat Cruise", type: "Adventure", cost: 60, duration: "2 hours", description: "Relaxing cruise with panoramic sunset views." },
  { name: "Cooking Class", type: "Food", cost: 55, duration: "3 hours", description: "Hands-on class learning to cook a traditional dish." },
  { name: "Hiking & Nature Trail", type: "Adventure", cost: 20, duration: "4 hours", description: "Scenic trail with breathtaking viewpoints." },
  { name: "Nightlife & Bar Hopping", type: "Nightlife", cost: 35, duration: "3 hours", description: "Guided evening tour of the best local bars." },
  { name: "Historic Landmark Visit", type: "Sightseeing", cost: 18, duration: "1.5 hours", description: "Skip-the-line entry to a must-see landmark." },
  { name: "Local Market Exploration", type: "Culture", cost: 10, duration: "1.5 hours", description: "Wander through bustling markets full of local goods." },
  { name: "Day Trip to Nearby Attraction", type: "Adventure", cost: 70, duration: "6 hours", description: "Full-day excursion to a must-see spot outside the city." },
];

/** Seeds cities + activities into db.json, but ONLY if those collections
 * are currently empty. Safe to call on every server start. */
function seedIfEmpty() {
  const existingCities = getCollection("cities");
  if (existingCities.length > 0) return { seeded: false };

  const createdCities = cities.map((c) => ({ id: uuid(), ...c }));
  saveCollection("cities", createdCities);

  const createdActivities = [];
  createdCities.forEach((city) => {
    activityTemplates.forEach((tmpl) => {
      createdActivities.push({
        id: uuid(),
        cityId: city.id,
        name: `${tmpl.name} - ${city.name}`,
        type: tmpl.type,
        cost: Math.round(tmpl.cost * (city.costIndex / 60)),
        duration: tmpl.duration,
        description: tmpl.description,
        image: city.image,
      });
    });
  });
  saveCollection("activities", createdActivities);

  return { seeded: true, cities: createdCities.length, activities: createdActivities.length };
}

// Allow `npm run seed` to still work as a standalone script.
if (require.main === module) {
  const result = seedIfEmpty();
  if (result.seeded) {
    console.log(`Seeded ${result.cities} cities and ${result.activities} activities.`);
  } else {
    console.log("Skipping seed - cities already exist in data/db.json.");
  }
}

module.exports = { seedIfEmpty };
