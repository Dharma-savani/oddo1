/**
 * config/db.js
 * -----------------------------------------------------------------------
 * Lightweight file-based JSON "database" for oddo1 (GlobeTrotter).
 *
 * Why not MySQL/Postgres directly? For a hackathon-speed build we want
 * zero external services to install/configure. Everything here is written
 * behind the same kind of interface a real DB layer would expose
 * (find/insert/update/delete per collection), so swapping this out for
 * MySQL + an ORM (e.g. Sequelize) later only means rewriting this file -
 * models/controllers do not need to change.
 * -----------------------------------------------------------------------
 */
const fs = require("fs");
const path = require("path");

const DB_FILE = path.join(__dirname, "..", "data", "db.json");

const DEFAULT_DB = {
  users: [],
  trips: [],
  stops: [],
  stopActivities: [],
  cities: [],
  activities: [],
};

function ensureDbFile() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2));
  }
}

function readDb() {
  ensureDbFile();
  const raw = fs.readFileSync(DB_FILE, "utf-8");
  try {
    return JSON.parse(raw);
  } catch (err) {
    console.error("Failed to parse db.json, resetting to default.", err);
    fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2));
    return { ...DEFAULT_DB };
  }
}

function writeDb(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

/** Generic collection helpers, used by every model file. */
function getCollection(name) {
  const db = readDb();
  if (!db[name]) db[name] = [];
  return db[name];
}

function saveCollection(name, records) {
  const db = readDb();
  db[name] = records;
  writeDb(db);
}

module.exports = { readDb, writeDb, getCollection, saveCollection, DB_FILE };
