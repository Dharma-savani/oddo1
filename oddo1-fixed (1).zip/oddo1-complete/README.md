# oddo1 (GlobeTrotter) — Trip Planning App

## How to run

### Easiest way (Windows / Mac / Linux - no typing commands)

1. Unzip this whole folder.
2. **Windows:** double-click `START_HERE_WINDOWS.bat`
   **Mac/Linux:** double-click `START_HERE_MAC_LINUX.command`
3. A black window will open and start the server - leave it open while
   you use the app. Your browser will open automatically to
   `http://localhost:5000` after a couple of seconds.
4. To stop the app later, just close that black window.

**Important: never open the files inside `frontend/` directly (no
double-clicking `login.html` etc., and no `file://...` links).** That
loads the page with no backend attached, which is why buttons look
"dead" and searches return nothing - the page has nothing to talk to.
Always start it through the launcher above (or `node server.js`, see
below) and browse to `http://localhost:5000`.

### Manual way (command line)

```bash
cd backend
npm install      # only needed once, or if node_modules isn't already present
npm start        # starts server on http://localhost:5000
```

Then open **http://localhost:5000** in your browser (any browser -
Chrome, Firefox, Edge all work the same way). The backend also serves
the `frontend/` folder as static files, so you don't need a separate
server.

### Data is seeded automatically - no manual steps

The very first time the server starts, it automatically loads 48 real
cities (spanning every continent, plus several Indian cities - Mumbai,
Delhi, Surat, Ahmedabad, Bengaluru, Chennai, Kolkata, Udaipur - each
with 10 activities = 480 activities) into `backend/data/db.json` if
that file is empty. You never have to run
a manual seed command or manually type in cities/activities - City
Search, Activity Search, and the Dashboard will always have real data to
show. This also means the app behaves dynamically: any city/activity you
see came from the auto-loaded dataset, not something you have to type in
by hand.

(If you ever want to wipe your data and start over, replace the contents
of `backend/data/db.json` with `{"users":[],"trips":[],"stops":[],"stopActivities":[],"cities":[],"activities":[]}`
and restart the server - it will re-seed automatically.)

### Using it from another device / browser on your network

`frontend/js/api.js` now points API calls at whatever host the page was
loaded from (`window.location.hostname`), not a hardcoded `localhost`.
So if you run `node server.js` on your laptop and want to open the app
from your phone or a teammate's browser on the same Wi-Fi, find your
laptop's LAN IP (e.g. `192.168.1.23`) and open
`http://192.168.1.23:5000` there - it will work the same as on
`localhost`. This is also what was silently breaking things before:
the old code always pointed at `http://localhost:5000`, which only
ever meant "the machine the browser itself is running on" - so it
broke the moment the app was opened from a different device.

## What's wired end-to-end

Signup → Login → Dashboard → Create Trip → Add Stops (City Search) → Add
Activities (Activity Search) → Itinerary Builder → Itinerary View → Budget
View → Calendar View → Share/Copy Public Itinerary → Profile (edit
name/language, logout, delete account).

All of the above call the real backend (JWT auth, JSON-file storage in
`backend/data/db.json`).

## Known limitations (by design, not bugs)

- **Storage is a JSON file**, not MySQL/Postgres — fine for a demo/hackathon,
  but not for concurrent production traffic. `backend/config/db.js` is
  written so swapping in a real DB later only means rewriting that one file.
- **Admin page (`adminprofile.html`) is UI-only.** The backend has no
  admin API (no "list all users", no moderation endpoints) — the page is
  guarded so only the first registered account can open it, but the data on
  it is still the static design mock. Add `backend/routes/admin.routes.js`
  + controller if you need real admin features.
- Preferences/notifications/currency settings shown in earlier profile
  mockups were removed from `profile.html` since the backend doesn't
  persist them (only `fullname` and `language` are saved).
- No password reset / email verification flow.
- No image upload for avatars or trip cover photos (fields exist in the
  data model but there's no upload endpoint).

## Folder structure

```
backend/
  config/db.js         - JSON file-based data layer
  models/               - one file per collection (user, trip, stop, city, activity, budget)
  controllers/           - request handlers
  routes/                - Express routers
  middleware/auth.middleware.js
  data/seed.js           - sample cities/activities
  server.js
  .env                   - PORT, JWT_SECRET, JWT_EXPIRES_IN
frontend/
  *.html                 - one page per screen
  js/api.js              - shared fetch client (window.oddo1.api.*)
  js/<page>.js            - per-page wiring
```
