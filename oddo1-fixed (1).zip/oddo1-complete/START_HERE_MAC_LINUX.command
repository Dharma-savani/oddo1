#!/bin/bash
cd "$(dirname "$0")/backend"

echo "============================================"
echo "  oddo1 (GlobeTrotter) - Starting Server"
echo "============================================"
echo ""

if ! command -v node &> /dev/null; then
    echo "Node.js is NOT installed on this computer."
    echo ""
    echo "Please install it first:"
    echo "  1. Go to https://nodejs.org"
    echo "  2. Download and install the LTS version"
    echo "  3. Run this file again"
    echo ""
    read -p "Press Enter to close..."
    exit 1
fi

if [ ! -d "node_modules" ]; then
    echo "Installing required packages, please wait a moment..."
    npm install
    echo ""
fi

echo "Starting the server..."
echo "DO NOT CLOSE THIS WINDOW while using the app."
echo ""
echo "Your browser will open automatically in a few seconds."
echo "If it doesn't, manually go to: http://localhost:5000"
echo ""

( sleep 2 && open "http://localhost:5000" 2> /dev/null || xdg-open "http://localhost:5000" 2> /dev/null ) &

node server.js

echo ""
echo "Server stopped."
read -p "Press Enter to close..."
