// NOTE: The backend currently exposes no admin-only endpoints (no user list,
// no moderation actions, no global stats). This page is guarded so only the
// first-ever registered account (isAdmin: true, set automatically by the
// backend) can view it, but the data shown on this page is still the static
// design mockup — wiring it to real data requires new backend routes
// (e.g. GET /api/admin/users) that don't exist yet.

if (!oddo1.requireAuth()) {
  // redirected to login.html
}

(async function guard() {
  try {
    const user = await oddo1.api.me();
    if (!user.isAdmin) {
      oddo1.toast("Admin access only.", "error");
      window.location.href = "profile.html";
    }
  } catch (err) {
    window.location.href = "login.html";
  }
})();
