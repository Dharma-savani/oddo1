if (!oddo1.requireAuth()) {
  // redirected to login.html
}

const TRIP_ID = oddo1.qs("tripId");
if (!TRIP_ID) {
  document.getElementById("itineraryHero").innerHTML =
    '<p class="font-body-md text-body-md text-error">No trip selected. Go to <a href="mytrip.html" class="underline">My Trips</a> to pick one.</p>';
  throw new Error("Missing tripId");
}

function renderHero(trip) {
  const stops = trip.stops || [];
  document.getElementById("itineraryHero").innerHTML = `
    <div class="flex items-center gap-2 mb-2 text-primary font-label-sm text-label-sm uppercase tracking-widest">
      <span class="material-symbols-outlined text-[16px]">calendar_month</span>
      <span>${oddo1.dateRange(trip.startDate, trip.endDate)} • ${stops.length} stop${stops.length === 1 ? "" : "s"}</span>
    </div>
    <h1 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">${trip.name}</h1>
    ${trip.description ? `<p class="font-body-md text-body-md text-on-surface-variant mt-2">${trip.description}</p>` : ""}
  `;
}

function renderTimeline(trip) {
  const stops = trip.stops || [];
  const el = document.getElementById("itineraryTimeline");
  if (!stops.length) {
    el.innerHTML = `<p class="font-body-md text-body-md text-on-surface-variant py-8 text-center">No cities added yet. <a href="itinerarybuilder.html?tripId=${TRIP_ID}" class="underline text-primary">Add stops in the builder</a>.</p>`;
    return;
  }
  el.innerHTML = stops
    .map((stop) => {
      const city = stop.city;
      const activities = stop.activities || [];
      const activitiesHtml = activities.length
        ? activities
            .map(
              (sa) => `
          <div class="glass-panel rounded-xl p-4 mb-3">
            <div class="flex justify-between items-start mb-1">
              <div class="font-label-sm text-label-sm text-primary">${sa.scheduledTime || "Time TBD"}</div>
              <span class="font-label-sm text-[10px] text-on-surface-variant px-1">${sa.activity ? oddo1.money(sa.activity.cost) : ""}</span>
            </div>
            <h4 class="font-headline-md text-[18px] leading-6 text-on-surface mb-1">${sa.activity ? sa.activity.name : "Activity"}</h4>
            <p class="font-body-md text-body-md text-on-surface-variant text-sm">${sa.activity && sa.activity.description ? sa.activity.description : ""}</p>
          </div>`
            )
            .join("")
        : `<p class="font-body-md text-body-md text-on-surface-variant text-sm py-2">No activities planned yet.</p>`;

      return `
      <div class="mb-stack-lg">
        <div class="flex items-center gap-3 mb-stack-sm sticky top-20 z-40 bg-background/90 backdrop-blur-sm py-4">
          <span class="material-symbols-outlined text-primary text-[28px]">location_on</span>
          <h2 class="font-headline-md text-headline-md text-on-surface">${city ? `${city.name}, ${city.country}` : "Unknown city"}</h2>
          <span class="ml-auto font-label-md text-label-md text-on-surface-variant bg-surface-variant px-3 py-1 rounded-full">${oddo1.dateRange(stop.startDate, stop.endDate)}</span>
        </div>
        ${activitiesHtml}
      </div>`;
    })
    .join("");
}

async function renderBudget() {
  try {
    const budget = await oddo1.api.getBudget(TRIP_ID);
    document.getElementById("itineraryBudgetSummary").innerHTML = `
      <div class="flex justify-between py-1"><span>Activities</span><span>${oddo1.money(budget.breakdown.activities)}</span></div>
      <div class="flex justify-between py-1"><span>Transport</span><span>${oddo1.money(budget.breakdown.transport)}</span></div>
      <div class="flex justify-between py-1"><span>Stay</span><span>${oddo1.money(budget.breakdown.stay)}</span></div>
      <div class="flex justify-between py-1"><span>Meals</span><span>${oddo1.money(budget.breakdown.meals)}</span></div>
      <div class="flex justify-between py-2 mt-2 border-t border-outline-variant/30 font-semibold text-on-surface"><span>Total</span><span>${oddo1.money(budget.total)}</span></div>
    `;
  } catch (err) {
    document.getElementById("itineraryBudgetSummary").textContent = "Could not load budget.";
  }
}

document.getElementById("viewFullBudgetBtn").addEventListener("click", () => {
  window.location.href = `budgetview.html?tripId=${TRIP_ID}`;
});

document.getElementById("shareTripBtn").addEventListener("click", async () => {
  const btn = document.getElementById("shareTripBtn");
  btn.disabled = true;
  btn.textContent = "Generating link...";
  try {
    const data = await oddo1.api.shareTrip(TRIP_ID);
    const fullUrl = `${window.location.origin}${data.shareUrl}`;
    document.getElementById("shareLinkResult").innerHTML =
      `Public link: <a href="${data.shareUrl}" class="text-primary underline">${fullUrl}</a>`;
    oddo1.toast("Trip is now shareable!");
  } catch (err) {
    oddo1.toast(err.message, "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "Share Public Link";
  }
});

async function loadTrip() {
  try {
    const trip = await oddo1.api.getTrip(TRIP_ID);
    renderHero(trip);
    renderTimeline(trip);
    renderBudget();
  } catch (err) {
    document.getElementById("itineraryHero").innerHTML =
      `<p class="font-body-md text-body-md text-error">${err.message}</p>`;
  }
}

loadTrip();
