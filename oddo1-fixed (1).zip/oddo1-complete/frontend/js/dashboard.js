if (!oddo1.requireAuth()) {
  // redirected to login.html
}

function tripCardHtml(trip) {
  const stops = trip.stops || [];
  const firstCity = stops[0] && stops[0].city ? stops[0].city.name : trip.name;
  const img =
    trip.coverPhoto ||
    (stops[0] && stops[0].city && stops[0].city.image) ||
    "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800";
  let daysLabel = "Dates TBD";
  if (trip.startDate) {
    const diff = Math.ceil((new Date(trip.startDate) - new Date()) / 86400000);
    daysLabel = diff > 0 ? `In ${diff} Days` : diff === 0 ? "Today" : "In progress";
  }
  return `
  <div onclick="location.href='itineraryview.html?tripId=${trip.id}'" class="min-w-[280px] w-[280px] md:min-w-[320px] rounded-3xl overflow-hidden relative soft-shadow group cursor-pointer">
      <div class="aspect-[4/5] w-full relative">
          <img alt="${trip.name}" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="${img}"/>
          <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
          <div class="absolute top-4 right-4 bg-surface-bright/90 backdrop-blur-md px-3 py-1 rounded-full font-label-sm text-label-sm text-primary flex items-center gap-1">
              <span class="material-symbols-outlined text-[14px]" style="font-variation-settings: 'FILL' 1;">calendar_month</span>
              ${daysLabel}
          </div>
          <div class="absolute bottom-0 left-0 w-full p-5 glass-card rounded-b-3xl !rounded-t-none !border-0 !border-t !border-white/20">
              <h3 class="font-headline-md text-headline-md text-on-surface mb-1">${trip.name}</h3>
              <p class="font-body-md text-body-md text-on-surface-variant/80 mb-3 text-sm">${oddo1.dateRange(trip.startDate, trip.endDate)}</p>
              <p class="font-label-sm text-label-sm text-on-surface-variant">${stops.length} stop${stops.length === 1 ? "" : "s"} · ${firstCity}</p>
          </div>
      </div>
  </div>`;
}

function emptyStateHtml() {
  return `
  <div class="min-w-[280px] w-[280px] md:min-w-[320px] rounded-3xl overflow-hidden relative soft-shadow group">
      <div class="aspect-[4/5] w-full relative bg-surface-container-high border border-outline-variant/30 flex flex-col items-center justify-center p-6 text-center">
          <div class="w-16 h-16 rounded-full bg-surface-bright flex items-center justify-center mb-4 text-primary">
              <span class="material-symbols-outlined text-3xl" style="font-variation-settings: 'FILL' 0;">flight_takeoff</span>
          </div>
          <h3 class="font-headline-md text-headline-md text-on-surface mb-2">Dreaming of somewhere?</h3>
          <p class="font-body-md text-body-md text-on-surface-variant text-sm mb-4">Start organizing your ideas for future getaways.</p>
          <button onclick="location.href='createtrip.html'" class="font-label-md text-label-md text-primary hover:bg-primary/10 px-4 py-2 rounded-full transition-colors">Start Draft</button>
      </div>
  </div>`;
}

async function loadDashboard() {
  const hour = new Date().getHours();
  document.getElementById("greetingTime").textContent =
    hour < 12 ? "Good morning," : hour < 18 ? "Good afternoon," : "Good evening,";

  try {
    const user = oddo1.getUser() || (await oddo1.api.me());
    document.getElementById("greetingName").textContent = user.fullname || "Traveler";
    if (user.avatar) document.getElementById("headerAvatar").src = user.avatar;
  } catch (e) {
    oddo1.toast(e.message, "error");
  }

  const container = document.getElementById("upcomingTripsContainer");
  try {
    const trips = await oddo1.api.listTrips();
    container.innerHTML = trips.length
      ? trips.slice(0, 6).map(tripCardHtml).join("") + emptyStateHtml()
      : emptyStateHtml();
  } catch (e) {
    container.innerHTML = emptyStateHtml();
    oddo1.toast(e.message, "error");
  }
}

loadDashboard();
