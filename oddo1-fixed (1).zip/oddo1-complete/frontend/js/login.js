// js/login.js - wires the login.html form to the backend auth API

// If already logged in, skip straight to dashboard.
if (oddo1.isLoggedIn()) {
  window.location.href = "dashboard.html";
}

document.getElementById("goSignupTab").addEventListener("click", function () {
  window.location.href = "signup.html";
});

const loginForm = document.getElementById("loginForm");
const loginError = document.getElementById("loginError");
const loginSubmitBtn = document.getElementById("loginSubmitBtn");

function showError(message) {
  loginError.textContent = message;
  loginError.classList.remove("hidden");
}

function hideError() {
  loginError.classList.add("hidden");
  loginError.textContent = "";
}

loginForm.addEventListener("submit", async function (e) {
  e.preventDefault();
  hideError();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  if (!email || !password) {
    showError("Please enter both email and password.");
    return;
  }

  loginSubmitBtn.disabled = true;
  loginSubmitBtn.textContent = "Logging in...";

  try {
    await oddo1.api.login(email, password); // api.login() already stores the session
    window.location.href = "dashboard.html";
  } catch (err) {
    showError(err.message || "Invalid email or password.");
  } finally {
    loginSubmitBtn.disabled = false;
    loginSubmitBtn.textContent = "Log In";
  }
});
