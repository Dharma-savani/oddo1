if (!oddo1.requireAuth()) {
  // redirected to login.html
}

const TRIP_ID = oddo1.qs("tripId");
if (!TRIP_ID) {
  document.getElementById("budgetTripName").textContent =
    "No trip selected. Go to My Trips to pick one.";
  throw new Error("Missing tripId");
}

function renderBreakdown(budget) {
  document.getElementById("budgetTotal").textContent = oddo1.money(budget.total);
  document.getElementById("budgetPerDay").textContent = `${oddo1.money(budget.perDayAverage)} / day over ${budget.days} day${budget.days === 1 ? "" : "s"}`;

  const limitNote = document.getElementById("budgetLimitNote");
  if (budget.budgetLimit) {
    limitNote.textContent = budget.overBudget
      ? `Over your ${oddo1.money(budget.budgetLimit)} limit`
      : `Within your ${oddo1.money(budget.budgetLimit)} limit`;
    limitNote.className = "font-label-sm text-label-sm mt-3 " + (budget.overBudget ? "text-error" : "text-secondary");
  } else {
    limitNote.textContent = "";
  }

  const rows = [
    ["Activities", budget.breakdown.activities, "confirmation_number"],
    ["Transport", budget.breakdown.transport, "directions_car"],
    ["Stay", budget.breakdown.stay, "hotel"],
    ["Meals", budget.breakdown.meals, "restaurant"],
  ];
  document.getElementById("budgetBreakdown").innerHTML = rows
    .map(
      ([label, value, icon]) => `
    <div class="flex items-center justify-between">
      <div class="flex items-center gap-2 text-on-surface-variant">
        <span class="material-symbols-outlined text-[18px]">${icon}</span>
        <span class="font-body-md text-body-md">${label}</span>
      </div>
      <span class="font-label-md text-label-md text-on-surface">${oddo1.money(value)}</span>
    </div>`
    )
    .join("");

  const activityList = budget.activityBreakdown || [];
  document.getElementById("budgetActivityList").innerHTML = activityList.length
    ? activityList
        .map(
          (a) => `
      <div class="flex items-center justify-between py-2 border-b border-outline-variant/20 last:border-0">
        <span class="font-body-md text-body-md text-on-surface">${a.name}</span>
        <span class="font-label-sm text-label-sm text-on-surface-variant">${oddo1.money(a.cost)}</span>
      </div>`
        )
        .join("")
    : `<p class="font-body-md text-body-md text-on-surface-variant text-sm">No activities added yet.</p>`;
}

async function loadBudget() {
  try {
    const trip = await oddo1.api.getTrip(TRIP_ID);
    document.getElementById("budgetTripName").textContent = trip.name;
    document.getElementById("extraTransport").value = (trip.budgetExtras && trip.budgetExtras.transport) || 0;
    document.getElementById("extraStay").value = (trip.budgetExtras && trip.budgetExtras.stay) || 0;
    document.getElementById("extraMeals").value = (trip.budgetExtras && trip.budgetExtras.meals) || 0;

    const budget = await oddo1.api.getBudget(TRIP_ID);
    renderBreakdown(budget);
  } catch (err) {
    document.getElementById("budgetTripName").textContent = err.message;
    oddo1.toast(err.message, "error");
  }
}

document.getElementById("budgetExtrasForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const transport = Number(document.getElementById("extraTransport").value) || 0;
  const stay = Number(document.getElementById("extraStay").value) || 0;
  const meals = Number(document.getElementById("extraMeals").value) || 0;
  try {
    await oddo1.api.updateTrip(TRIP_ID, { budgetExtras: { transport, stay, meals } });
    const budget = await oddo1.api.getBudget(TRIP_ID);
    renderBreakdown(budget);
    oddo1.toast("Budget updated!");
  } catch (err) {
    oddo1.toast(err.message, "error");
  }
});

loadBudget();
