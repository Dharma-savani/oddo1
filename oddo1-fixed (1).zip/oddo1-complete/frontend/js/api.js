/**
 * js/api.js
 * -----------------------------------------------------------------------
 * Shared frontend API client for oddo1 (GlobeTrotter).
 * Include this on every page BEFORE your page-specific <script>:
 *   <script src="js/api.js"></script>
 *
 * Everything hangs off the global `oddo1` object so plain <script> tags
 * (no bundler / no type="module") can use it directly, e.g:
 *   oddo1.api.login(email, password)
 *   oddo1.requireAuth()
 *   oddo1.money(42.5)
 * -----------------------------------------------------------------------
 */
(function () {
  // If the frontend is served BY the backend (node server.js serves /frontend
  // as static files), same-origin relative "/api" works - this is true
  // whether you open it as http://localhost:5000 or http://<your-lan-ip>:5000,
  // so the app works the same in any browser and from any device on the
  // network, not just "localhost".
  //
  // If you run the frontend separately (e.g. `npx serve frontend`, or you
  // double-click the .html files so the page is on a different port or on
  // file://), fall back to the backend on port 5000 of the SAME machine the
  // page is loaded from (window.location.hostname) instead of a hardcoded
  // "localhost" - that hardcoding is what breaks the app when it's opened
  // from another device/browser on the network.
  const API_BASE = (function () {
    if (window.location.port === "5000") return "/api";
    const host = window.location.hostname || "localhost";
    return `${window.location.protocol === "https:" ? "https:" : "http:"}//${host}:5000/api`;
  })();

  const TOKEN_KEY = "oddo1_token";
  const USER_KEY = "oddo1_user";

  function getToken() {
    return localStorage.getItem(TOKEN_KEY);
  }

  function setSession(token, user) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  function clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }

  function getUser() {
    try {
      return JSON.parse(localStorage.getItem(USER_KEY) || "null");
    } catch (e) {
      return null;
    }
  }

  function isLoggedIn() {
    return !!getToken();
  }

  /** Redirect to login if not authenticated. Call at the top of protected pages. */
  function requireAuth() {
    if (!isLoggedIn()) {
      window.location.href = "login.html";
      return false;
    }
    return true;
  }

  function logout() {
    clearSession();
    window.location.href = "login.html";
  }

  async function request(path, { method = "GET", body, auth = true, params } = {}) {
    let url = API_BASE + path;
    if (params) {
      const qs = new URLSearchParams(
        Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== "")
      ).toString();
      if (qs) url += "?" + qs;
    }

    const headers = { "Content-Type": "application/json" };
    if (auth && getToken()) headers.Authorization = "Bearer " + getToken();

    let res;
    try {
      res = await fetch(url, {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch (networkErr) {
      throw new Error(
        "Could not reach the oddo1 server. Is the backend running on http://localhost:5000?"
      );
    }

    let data = null;
    try {
      data = await res.json();
    } catch (e) {
      /* empty body */
    }

    if (!res.ok) {
      const message = (data && data.message) || `Request failed (${res.status})`;
      if (res.status === 401 && auth) {
        clearSession();
      }
      throw new Error(message);
    }
    return data;
  }

  const api = {
    // ---- auth ----
    async signup(fullname, email, password) {
      const data = await request("/auth/signup", {
        method: "POST",
        body: { fullname, email, password },
        auth: false,
      });
      setSession(data.token, data.user);
      return data;
    },
    async login(email, password) {
      const data = await request("/auth/login", {
        method: "POST",
        body: { email, password },
        auth: false,
      });
      setSession(data.token, data.user);
      return data;
    },
    async me() {
      const data = await request("/auth/me");
      setSession(getToken(), data.user);
      return data.user;
    },
    async updateProfile(patch) {
      const data = await request("/auth/me", { method: "PUT", body: patch });
      setSession(getToken(), data.user);
      return data.user;
    },
    async deleteAccount() {
      await request("/auth/me", { method: "DELETE" });
      clearSession();
    },

    // ---- cities ----
    listCities(search, country) {
      return request("/cities", { params: { search, country }, auth: false }).then(
        (d) => d.cities
      );
    },
    getCity(id) {
      return request(`/cities/${id}`, { auth: false }).then((d) => d.city);
    },

    // ---- activities ----
    listActivities(filters = {}) {
      return request("/activities", { params: filters, auth: false }).then(
        (d) => d.activities
      );
    },
    getActivity(id) {
      return request(`/activities/${id}`, { auth: false }).then((d) => d.activity);
    },

    // ---- trips ----
    listTrips() {
      return request("/trips").then((d) => d.trips);
    },
    getTrip(id) {
      return request(`/trips/${id}`).then((d) => d.trip);
    },
    createTrip(payload) {
      return request("/trips", { method: "POST", body: payload }).then((d) => d.trip);
    },
    updateTrip(id, patch) {
      return request(`/trips/${id}`, { method: "PUT", body: patch }).then((d) => d.trip);
    },
    deleteTrip(id) {
      return request(`/trips/${id}`, { method: "DELETE" });
    },
    shareTrip(id) {
      return request(`/trips/${id}/share`, { method: "POST" });
    },
    unshareTrip(id) {
      return request(`/trips/${id}/unshare`, { method: "POST" }).then((d) => d.trip);
    },
    getPublicTrip(token) {
      return request(`/public/trips/${token}`, { auth: false }).then((d) => d.trip);
    },
    copyPublicTrip(token) {
      return request(`/trips/${token}/copy`, { method: "POST" }).then((d) => d.trip);
    },
    getBudget(tripId) {
      return request(`/trips/${tripId}/budget`).then((d) => d.budget);
    },

    // ---- stops ----
    addStop(tripId, payload) {
      return request(`/trips/${tripId}/stops`, { method: "POST", body: payload }).then(
        (d) => d.trip
      );
    },
    updateStop(tripId, stopId, patch) {
      return request(`/trips/${tripId}/stops/${stopId}`, {
        method: "PUT",
        body: patch,
      }).then((d) => d.trip);
    },
    removeStop(tripId, stopId) {
      return request(`/trips/${tripId}/stops/${stopId}`, { method: "DELETE" }).then(
        (d) => d.trip
      );
    },
    reorderStops(tripId, stopIds) {
      return request(`/trips/${tripId}/stops-reorder`, {
        method: "PUT",
        body: { stopIds },
      }).then((d) => d.trip);
    },

    // ---- stop activities ----
    addActivityToStop(tripId, stopId, payload) {
      return request(`/trips/${tripId}/stops/${stopId}/activities`, {
        method: "POST",
        body: payload,
      }).then((d) => d.trip);
    },
    removeActivityFromStop(tripId, activityLinkId) {
      return request(`/trips/${tripId}/activities/${activityLinkId}`, {
        method: "DELETE",
      }).then((d) => d.trip);
    },
  };

  /* ------------------------------- helpers ------------------------------- */

  function money(n) {
    const num = Number(n) || 0;
    return "$" + num.toLocaleString(undefined, { maximumFractionDigits: 2 });
  }

  function formatDate(dateStr) {
    if (!dateStr) return "";
    const d = new Date(dateStr);
    if (isNaN(d)) return dateStr;
    return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  }

  function dateRange(start, end) {
    if (!start && !end) return "Dates TBD";
    return `${formatDate(start)} - ${formatDate(end)}`;
  }

  function qs(name) {
    return new URLSearchParams(window.location.search).get(name);
  }

  function toast(message, kind = "info") {
    let el = document.getElementById("oddo1-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "oddo1-toast";
      el.style.cssText =
        "position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:9999;" +
        "padding:12px 20px;border-radius:9999px;font-family:sans-serif;font-size:14px;" +
        "box-shadow:0 8px 24px rgba(0,0,0,0.2);transition:opacity .3s;max-width:90vw;text-align:center;";
      document.body.appendChild(el);
    }
    el.style.background = kind === "error" ? "#ba1a1a" : "#99462a";
    el.style.color = "#fff";
    el.textContent = message;
    el.style.opacity = "1";
    clearTimeout(el._hideTimer);
    el._hideTimer = setTimeout(() => {
      el.style.opacity = "0";
    }, 3200);
  }

  window.oddo1 = {
    api,
    getToken,
    getUser,
    setSession,
    clearSession,
    isLoggedIn,
    requireAuth,
    logout,
    money,
    formatDate,
    dateRange,
    qs,
    toast,
  };
})();
