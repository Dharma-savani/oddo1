// js/signup.js - wires the signup.html form to the backend auth API

if (oddo1.isLoggedIn()) {
  window.location.href = "dashboard.html";
}

document.getElementById("goLoginTab").addEventListener("click", function () {
  window.location.href = "login.html";
});

const signupForm = document.getElementById("signupForm");
const signupError = document.getElementById("signupError");
const signupSubmitBtn = document.getElementById("signupSubmitBtn");

function showSignupError(message) {
  signupError.textContent = message;
  signupError.classList.remove("hidden");
}

function hideSignupError() {
  signupError.classList.add("hidden");
  signupError.textContent = "";
}

signupForm.addEventListener("submit", async function (e) {
  e.preventDefault();
  hideSignupError();

  const fullname = document.getElementById("fullname").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  if (!fullname || !email || !password) {
    showSignupError("Please fill in every field.");
    return;
  }
  if (password.length < 6) {
    showSignupError("Password must be at least 6 characters.");
    return;
  }

  signupSubmitBtn.disabled = true;
  signupSubmitBtn.textContent = "Creating account...";

  try {
    await oddo1.api.signup(fullname, email, password); // stores the session itself
    window.location.href = "dashboard.html";
  } catch (err) {
    showSignupError(err.message || "Could not create your account.");
  } finally {
    signupSubmitBtn.disabled = false;
    signupSubmitBtn.textContent = "Create Account";
  }
});
