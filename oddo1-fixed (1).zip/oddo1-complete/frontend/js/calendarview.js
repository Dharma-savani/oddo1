if (!oddo1.requireAuth()) {
  // redirected to login.html
}

let currentDate = new Date();
currentDate.setDate(1);
let EVENTS_BY_DATE = {}; // "YYYY-MM-DD" -> [{ tripName, cityName, activityName, scheduledTime }]

function dateKey(d) {
  return d.toISOString().slice(0, 10);
}

async function loadEvents() {
  const map = {};
  try {
    const trips = await oddo1.api.listTrips();
    trips.forEach((trip) => {
      (trip.stops || []).forEach((stop) => {
        (stop.activities || []).forEach((sa) => {
          if (!sa.scheduledDate) return;
          const key = sa.scheduledDate.slice(0, 10);
          if (!map[key]) map[key] = [];
          map[key].push({
            tripName: trip.name,
            tripId: trip.id,
            cityName: stop.city ? stop.city.name : "",
            activityName: sa.activity ? sa.activity.name : "Activity",
            scheduledTime: sa.scheduledTime,
          });
        });
      });
    });
  } catch (err) {
    oddo1.toast(err.message, "error");
  }
  EVENTS_BY_DATE = map;
}

function renderCalendar() {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  document.getElementById("calendarMonthLabel").textContent = currentDate.toLocaleDateString(undefined, {
    month: "long",
    year: "numeric",
  });

  const firstDay = new Date(year, month, 1);
  const startOffset = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const grid = document.getElementById("calendarGrid");

  let cellsHtml = "";
  for (let i = 0; i < startOffset; i++) {
    cellsHtml += `<div class="h-16 md:h-24"></div>`;
  }
  for (let day = 1; day <= daysInMonth; day++) {
    const cellDate = new Date(year, month, day);
    const key = dateKey(cellDate);
    const hasEvents = !!EVENTS_BY_DATE[key];
    const isToday = dateKey(new Date()) === key;
    cellsHtml += `
      <button data-date="${key}" class="calendar-day h-16 md:h-24 rounded-lg border ${isToday ? "border-primary" : "border-outline-variant/30"} ${hasEvents ? "bg-primary/5" : "bg-surface"} hover:bg-surface-variant/40 transition-colors flex flex-col items-center justify-start pt-2 gap-1">
        <span class="font-label-sm text-label-sm ${isToday ? "text-primary font-bold" : "text-on-surface"}">${day}</span>
        ${hasEvents ? `<span class="w-1.5 h-1.5 rounded-full bg-primary"></span>` : ""}
      </button>`;
  }
  grid.innerHTML = cellsHtml;

  grid.querySelectorAll(".calendar-day").forEach((btn) => {
    btn.addEventListener("click", () => showDay(btn.dataset.date));
  });
}

function showDay(key) {
  const events = EVENTS_BY_DATE[key] || [];
  const d = new Date(key + "T00:00:00");
  document.getElementById("selectedDayLabel").textContent = d.toLocaleDateString(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
  });
  document.getElementById("selectedDayActivities").innerHTML = events.length
    ? events
        .map(
          (ev) => `
      <div class="flex items-center justify-between py-2 border-b border-outline-variant/20 last:border-0 cursor-pointer" onclick="location.href='itineraryview.html?tripId=${ev.tripId}'">
        <div>
          <p class="font-label-md text-label-md text-on-surface">${ev.activityName}</p>
          <p class="font-label-sm text-label-sm text-on-surface-variant">${ev.tripName}${ev.cityName ? " · " + ev.cityName : ""}</p>
        </div>
        <span class="font-label-sm text-label-sm text-primary">${ev.scheduledTime || ""}</span>
      </div>`
        )
        .join("")
    : `<p class="font-body-md text-body-md text-on-surface-variant text-sm">Nothing scheduled this day.</p>`;
}

document.getElementById("prevMonthBtn").addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar();
});
document.getElementById("nextMonthBtn").addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar();
});

(async function init() {
  await loadEvents();
  renderCalendar();
})();
