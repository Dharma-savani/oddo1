if (!oddo1.requireAuth()) {
  // redirected to login.html
}

async function loadProfile() {
  try {
    const user = await oddo1.api.me();
    document.getElementById("profileName").textContent = user.fullname || "Traveler";
    document.getElementById("profileEmailDisplay").textContent = user.email || "";
    document.getElementById("profileFullName").value = user.fullname || "";
    document.getElementById("profileEmailInput").value = user.email || "";
    document.getElementById("profileLanguage").value = user.language || "English";
  } catch (err) {
    oddo1.toast(err.message, "error");
  }

  try {
    const trips = await oddo1.api.listTrips();
    document.getElementById("profileTripCount").textContent = `${trips.length} Trip${trips.length === 1 ? "" : "s"} Planned`;
  } catch (err) {
    /* non-critical */
  }
}

document.getElementById("profileForm").addEventListener("submit", async (e) => {
  e.preventDefault();
});

document.getElementById("saveProfileBtn").addEventListener("click", async () => {
  const fullname = document.getElementById("profileFullName").value.trim();
  const language = document.getElementById("profileLanguage").value;
  if (!fullname) {
    oddo1.toast("Full name can't be empty.", "error");
    return;
  }
  const btn = document.getElementById("saveProfileBtn");
  btn.disabled = true;
  btn.textContent = "Saving...";
  try {
    const user = await oddo1.api.updateProfile({ fullname, language });
    document.getElementById("profileName").textContent = user.fullname;
    oddo1.toast("Profile updated!");
  } catch (err) {
    oddo1.toast(err.message, "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "Save Changes";
  }
});

document.getElementById("logoutBtn").addEventListener("click", () => {
  oddo1.logout();
});

document.getElementById("deleteAccountBtn").addEventListener("click", async () => {
  if (!confirm("This will permanently delete your account and all your trips. Continue?")) return;
  try {
    await oddo1.api.deleteAccount();
    oddo1.toast("Account deleted.");
    window.location.href = "login.html";
  } catch (err) {
    oddo1.toast(err.message, "error");
  }
});

loadProfile();
