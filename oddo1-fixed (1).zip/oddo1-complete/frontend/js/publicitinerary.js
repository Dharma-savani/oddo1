// Public shared itinerary page. No login required to VIEW, but copying
// the trip into your own account needs auth (handled by api.js/copyPublicTrip).

const SHARE_TOKEN = oddo1.qs("token");
if (!SHARE_TOKEN) {
  document.getElementById("publicHero").innerHTML =
    '<p class="font-body-md text-body-md text-error">No shared trip link provided.</p>';
  throw new Error("Missing token");
}

function renderHero(trip) {
  const stops = trip.stops || [];
  document.getElementById("publicHero").innerHTML = `
    <div class="flex items-center gap-2 mb-2 text-primary font-label-sm text-label-sm uppercase tracking-widest">
      <span class="material-symbols-outlined text-[16px]">calendar_month</span>
      <span>${oddo1.dateRange(trip.startDate, trip.endDate)} • ${stops.length} stop${stops.length === 1 ? "" : "s"}</span>
    </div>
    <h1 class="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-on-surface">${trip.name}</h1>
    ${trip.description ? `<p class="font-body-md text-body-md text-on-surface-variant mt-2">${trip.description}</p>` : ""}
  `;
}

function renderTimeline(trip) {
  const stops = trip.stops || [];
  const el = document.getElementById("publicTimeline");
  if (!stops.length) {
    el.innerHTML = `<p class="font-body-md text-body-md text-on-surface-variant py-8 text-center">This trip has no stops yet.</p>`;
    return;
  }
  el.innerHTML = stops
    .map((stop) => {
      const city = stop.city;
      const activities = stop.activities || [];
      const activitiesHtml = activities.length
        ? activities
            .map(
              (sa) => `
          <div class="glass-panel rounded-xl p-4 mb-3">
            <div class="flex justify-between items-start mb-1">
              <div class="font-label-sm text-label-sm text-primary">${sa.scheduledTime || "Time TBD"}</div>
              <span class="font-label-sm text-[10px] text-on-surface-variant px-1">${sa.activity ? oddo1.money(sa.activity.cost) : ""}</span>
            </div>
            <h4 class="font-headline-md text-[18px] leading-6 text-on-surface mb-1">${sa.activity ? sa.activity.name : "Activity"}</h4>
            <p class="font-body-md text-body-md text-on-surface-variant text-sm">${sa.activity && sa.activity.description ? sa.activity.description : ""}</p>
          </div>`
            )
            .join("")
        : `<p class="font-body-md text-body-md text-on-surface-variant text-sm py-2">No activities planned yet.</p>`;

      return `
      <div class="mb-stack-lg">
        <div class="flex items-center gap-3 mb-stack-sm py-4">
          <span class="material-symbols-outlined text-primary text-[28px]">location_on</span>
          <h2 class="font-headline-md text-headline-md text-on-surface">${city ? `${city.name}, ${city.country}` : "Unknown city"}</h2>
          <span class="ml-auto font-label-md text-label-md text-on-surface-variant bg-surface-variant px-3 py-1 rounded-full">${oddo1.dateRange(stop.startDate, stop.endDate)}</span>
        </div>
        ${activitiesHtml}
      </div>`;
    })
    .join("");
}

document.getElementById("copyTripBtn").addEventListener("click", async () => {
  if (!oddo1.isLoggedIn()) {
    oddo1.toast("Please log in first to copy this trip.", "error");
    setTimeout(() => {
      window.location.href = `login.html?next=publicitinerary.html?token=${SHARE_TOKEN}`;
    }, 1200);
    return;
  }
  const btn = document.getElementById("copyTripBtn");
  btn.disabled = true;
  btn.textContent = "Copying...";
  try {
    const trip = await oddo1.api.copyPublicTrip(SHARE_TOKEN);
    oddo1.toast("Trip copied to your account!");
    window.location.href = `itinerarybuilder.html?tripId=${trip.id}`;
  } catch (err) {
    oddo1.toast(err.message, "error");
    btn.disabled = false;
    btn.innerHTML = '<span class="material-symbols-outlined">content_copy</span> Copy This Trip To My Account';
  }
});

async function loadPublicTrip() {
  try {
    const trip = await oddo1.api.getPublicTrip(SHARE_TOKEN);
    renderHero(trip);
    renderTimeline(trip);
  } catch (err) {
    document.getElementById("publicHero").innerHTML =
      `<p class="font-body-md text-body-md text-error">${err.message}</p>`;
    document.getElementById("copyTripBtn").classList.add("hidden");
  }
}

loadPublicTrip();
