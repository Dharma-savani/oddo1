if (!oddo1.requireAuth()) {
  // redirected to login.html
}

const TRIP_ID = oddo1.qs("tripId");
if (!TRIP_ID) {
  document.getElementById("timelineContainer").innerHTML =
    '<p class="font-body-md text-body-md text-error text-center py-8">No trip selected. Go to <a href="mytrip.html" class="underline">My Trips</a> and pick one to edit, or <a href="createtrip.html" class="underline">create a new trip</a>.</p>';
  throw new Error("Missing tripId");
}

const ICONS = ["hiking", "local_bar", "museum", "restaurant", "wb_twilight", "beach_access", "nightlife", "photo_camera"];
function iconFor(index) {
  return ICONS[index % ICONS.length];
}

function stopHtml(stop, index, isLast) {
  const cityName = stop.city ? `${stop.city.name}, ${stop.city.country}` : "Unknown city";
  const activities = stop.activities || [];
  const activitiesHtml = activities.length
    ? activities
        .map(
          (sa, i) => `
        <div class="glass-card rounded-xl p-4 flex items-center gap-4 group/activity">
            <div class="w-10 h-10 rounded-lg bg-surface-variant text-on-surface-variant flex items-center justify-center shrink-0">
                <span class="material-symbols-outlined">${iconFor(i)}</span>
            </div>
            <div class="flex-grow">
                <h3 class="font-label-md text-label-md text-on-surface font-semibold">${sa.activity ? sa.activity.name : "Activity"}</h3>
                <p class="font-body-md text-body-md text-[13px] text-on-surface-variant">${sa.activity ? oddo1.money(sa.activity.cost) : ""} ${sa.activity ? "· " + sa.activity.duration : ""}</p>
            </div>
            <button onclick="oddo1RemoveActivity('${sa.id}')" class="opacity-0 group-hover/activity:opacity-100 transition-opacity text-outline hover:text-error">
                <span class="material-symbols-outlined text-[20px]">delete</span>
            </button>
        </div>`
        )
        .join("")
    : `<div onclick="location.href='activitysearch.html?tripId=${TRIP_ID}&stopId=${stop.id}&cityId=${stop.cityId}'" class="border-2 border-dashed border-outline-variant/50 rounded-xl p-6 flex flex-col items-center justify-center text-center gap-2 hover:bg-surface-variant/30 transition-colors cursor-pointer">
        <span class="material-symbols-outlined text-outline">playlist_add</span>
        <p class="font-label-md text-label-md text-on-surface-variant">No activities planned yet.</p>
        <span class="font-label-sm text-label-sm text-primary">Tap to add your first activity</span>
      </div>`;

  return `
  <div class="timeline-item relative mb-stack-lg group">
    <div class="timeline-thread absolute inset-0 pointer-events-none"></div>
    <div class="flex items-start gap-4 mb-stack-sm relative z-10">
      <div class="w-12 h-12 rounded-full bg-primary-container text-on-primary-container flex items-center justify-center shrink-0 shadow-md">
        <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">location_on</span>
      </div>
      <div class="flex-grow pt-1 flex justify-between items-start">
        <div>
          <h2 class="font-headline-md text-headline-md text-on-surface">${cityName}</h2>
          <button onclick="oddo1EditStopDates('${stop.id}', '${stop.startDate || ""}', '${stop.endDate || ""}')" class="flex items-center gap-2 text-on-surface-variant mt-1 cursor-pointer hover:text-primary transition-colors">
            <span class="material-symbols-outlined text-[16px]">calendar_today</span>
            <span class="font-label-md text-label-md">${oddo1.dateRange(stop.startDate, stop.endDate)}</span>
          </button>
        </div>
        <button onclick="oddo1RemoveStop('${stop.id}')" class="text-outline hover:text-error transition-colors p-2 rounded-full hover:bg-surface-variant" aria-label="Remove stop">
          <span class="material-symbols-outlined">delete</span>
        </button>
      </div>
    </div>
    <div class="ml-[3.25rem] flex flex-col gap-3 relative z-10">
      ${activitiesHtml}
      ${activities.length ? `<button onclick="location.href='activitysearch.html?tripId=${TRIP_ID}&stopId=${stop.id}&cityId=${stop.cityId}'" class="flex items-center gap-2 mt-2 text-primary hover:text-on-primary-container transition-colors w-fit group/btn">
        <span class="material-symbols-outlined group-hover/btn:rotate-90 transition-transform">add</span>
        <span class="font-label-md text-label-md">Add Activity</span>
      </button>` : ""}
    </div>
  </div>`;
}

function renderTrip(trip) {
  document.getElementById("itineraryTripName").textContent = trip.name;
  const stops = trip.stops || [];
  const container = document.getElementById("timelineContainer");

  const stopsHtml = stops.map((s, i) => stopHtml(s, i, i === stops.length - 1)).join("");

  container.innerHTML = `
    ${stopsHtml || '<p class="font-body-md text-body-md text-on-surface-variant text-center py-4">No cities added yet. Start by adding your first stop below.</p>'}
    <div class="ml-[1.1rem] relative z-10 mt-stack-md">
      <button onclick="location.href='citysearch.html?tripId=${TRIP_ID}'" class="bg-primary text-on-primary rounded-full px-6 py-4 flex items-center gap-3 hover:bg-surface-tint hover:shadow-lg transition-all active:scale-95 group font-label-md text-label-md shadow-[0_8px_20px_rgba(153,70,42,0.2)]">
        <span class="material-symbols-outlined group-hover:rotate-180 transition-transform duration-500">add_location_alt</span>
        Add Another City
      </button>
    </div>
    <div class="ml-[1.1rem] relative z-10 mt-stack-md flex flex-wrap gap-3">
      <button onclick="location.href='itineraryview.html?tripId=${TRIP_ID}'" class="bg-surface border border-primary/40 text-primary rounded-full px-6 py-3 flex items-center gap-2 hover:bg-primary/5 transition-all active:scale-95 font-label-md text-label-md">
        <span class="material-symbols-outlined">visibility</span>
        Preview Itinerary
      </button>
      <button onclick="location.href='budgetview.html?tripId=${TRIP_ID}'" class="bg-surface border border-primary/40 text-primary rounded-full px-6 py-3 flex items-center gap-2 hover:bg-primary/5 transition-all active:scale-95 font-label-md text-label-md">
        <span class="material-symbols-outlined">payments</span>
        View Budget
      </button>
    </div>`;
}

async function loadTrip() {
  try {
    const trip = await oddo1.api.getTrip(TRIP_ID);
    renderTrip(trip);
  } catch (err) {
    document.getElementById("timelineContainer").innerHTML =
      `<p class="font-body-md text-body-md text-error text-center py-8">${err.message}</p>`;
    oddo1.toast(err.message, "error");
  }
}

async function oddo1EditStopDates(stopId, currentStart, currentEnd) {
  const startDate = prompt("Start date (YYYY-MM-DD):", currentStart || "");
  if (startDate === null) return;
  const endDate = prompt("End date (YYYY-MM-DD):", currentEnd || "");
  if (endDate === null) return;
  try {
    const trip = await oddo1.api.updateStop(TRIP_ID, stopId, { startDate, endDate });
    renderTrip(trip);
  } catch (err) {
    oddo1.toast(err.message, "error");
  }
}

async function oddo1RemoveStop(stopId) {
  if (!confirm("Remove this city and all its activities from the trip?")) return;
  try {
    const trip = await oddo1.api.removeStop(TRIP_ID, stopId);
    renderTrip(trip);
    oddo1.toast("City removed.");
  } catch (err) {
    oddo1.toast(err.message, "error");
  }
}

async function oddo1RemoveActivity(activityLinkId) {
  try {
    const trip = await oddo1.api.removeActivityFromStop(TRIP_ID, activityLinkId);
    renderTrip(trip);
    oddo1.toast("Activity removed.");
  } catch (err) {
    oddo1.toast(err.message, "error");
  }
}

loadTrip();
