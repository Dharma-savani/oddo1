@echo off
title oddo1 - GlobeTrotter Server
color 0A

echo ============================================
echo   oddo1 (GlobeTrotter) - Starting Server
echo ============================================
echo.

cd /d "%~dp0backend"

where node >nul 2>nul
if errorlevel 1 (
    echo Node.js is NOT installed on this computer.
    echo.
    echo Please install it first:
    echo   1. Go to https://nodejs.org
    echo   2. Download and install the "LTS" version
    echo   3. Restart your computer
    echo   4. Double-click this file again
    echo.
    pause
    exit /b
)

if not exist "node_modules" (
    echo Installing required packages, please wait a moment...
    call npm install
    echo.
)

echo Starting the server...
echo DO NOT CLOSE THIS WINDOW while using the app.
echo.
echo Your browser will open automatically in a few seconds.
echo If it doesn't, manually go to: http://localhost:5000
echo.

start "" cmd /c "timeout /t 2 >nul && start http://localhost:5000"

node server.js

echo.
echo Server stopped.
pause
